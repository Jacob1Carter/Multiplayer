from tools import backup_project


def main(port):
    pass


if __name__ == "__main__":
    backup_project()
    main()
